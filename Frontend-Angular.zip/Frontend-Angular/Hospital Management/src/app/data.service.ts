import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor() { }

  getDepartments(){
    return [
      "Physcolgy",
      "Gynnaceology",
      "Dermotology",
      "General"
    ]
  }
  getStates():String[]
  {
      return[
      "Andhra Pradesh",
      "Telangana",
      "Tamilnadu",
      "Karnataka"
      ]
  }
}
