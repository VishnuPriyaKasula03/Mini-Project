export class Departments
{
    getDepartments():String[]{
        return [
            "Cardiology",
            "Physcolgy",
            "Gynaceology"
    ]
    }
}