export class State
{
    getStates():String[]
    {
        return[
        "Andhra Pradesh",
        "Telangana",
        "Tamilnadu",
        "Karnataka"
        ]
    }
}